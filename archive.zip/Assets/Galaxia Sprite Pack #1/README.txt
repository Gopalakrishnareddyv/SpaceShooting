[GALAXIA SPACE SHOOTER SPRITE PACK]
CREATED BY JOSH MARSHALL
README

First of all, thank you for purchasing! I hope these sprites give you a head start in prototyping your very own game.

[PROVIDED FEATURES]

- 13 Enemy Sprite Variants
- 3 Player Sprites
- 11 Effect Sprite Variants

[SET-UP]

There is no initial set-up! All sprites have been cut and set appropriately, just assign them to a new gameobject to get started!

[EXTRA]

If you're looking for a code base to lay some groundwork on your very own space shooter head over to the 2D Space Shooter Template available on the asset store! You can drag and drop these 
sprites onto any existing or new gameobjects with no fuss.

https://www.assetstore.unity3d.com/en/#!/content/38282

[CONTACT ME]

For any advice and questions regarding this asset, please feel free to e-mail me at ferrety@losttitle.co.uk and 
I'll try to get back to you as soon as possible.